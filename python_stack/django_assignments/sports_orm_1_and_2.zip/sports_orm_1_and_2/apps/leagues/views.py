from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Count
from . import team_maker

def index(request):
	context = {
		"baseball_leagues": League.objects.filter(sport='Baseball'),
		"women_leagues": League.objects.filter(name__contains='Women'),
		"hockey_leagues": League.objects.filter(sport__contains='Hockey'),
		"not_football_leagues": League.objects.exclude(sport='Football'),
		"conference_leagues": League.objects.filter(name__contains='Conference'),
		"atlantic_leagues": League.objects.filter(name__contains='Atlantic'),
		"dallas_teams": Team.objects.filter(location='Dallas'),
		"raptors_teams": Team.objects.filter(team_name='Raptors'),
		"city_teams": Team.objects.filter(location__contains='City'),
		"T_teams": Team.objects.filter(team_name__startswith="T"),
		"alpha_teams": Team.objects.all().order_by('location'),
		"backwards_teams": Team.objects.all().order_by('-team_name'),
		"cooper_player": Player.objects.filter(last_name='Cooper'),
		"joshua_player": Player.objects.filter(first_name='Joshua'),
		"cooper_notjosh_player": Player.objects.filter(last_name='Cooper').exclude(first_name='Joshua'),
		"alexander_wyatt_player": Player.objects.filter(first_name='Alexander')|Player.objects.filter(first_name='Wyatt'),
		"atlantic_soccer_conf_teams": Team.objects.filter(league__name__contains='Atlantic Soccer Conference'),
		"boston_penguins_curr": Player.objects.filter(curr_team__team_name='Penguins'),
		"International_Collegiate_Baseball_Conference": Player.objects.filter(curr_team__league__name='International Collegiate Baseball Conference'),
		"American_Conference_of_Amateur_Football": Player.objects.filter(curr_team__league__name='American Conference of Amateur Football', last_name='Lopez'),
		"all_football_players": Player.objects.filter(curr_team__league__sport__contains='Football'),
		"team_sophia_players": Team.objects.filter(curr_players__first_name='Sophia'),
		"league_sophia_players": League.objects.filter(teams__curr_players__first_name='Sophia'),
		"flores_not_Washington_Roughriders": Player.objects.filter(last_name='Flores').exclude(curr_team__team_name='Roughriders'),
		"sam_evans_all_teams": Team.objects.filter(all_players__first_name='Samuel').filter(all_players__last_name = "Evans"),
		"all_players_mani_tiger_cats": Player.objects.filter(all_teams__team_name='Tiger-Cats'),
		"all_players_werewith_Vikings": Player.objects.filter(all_teams__team_name='Vikings').exclude(curr_team__team_name='Vikings'),
		"jacob_teams_before_colts": Team.objects.filter(all_players__first_name='Jacob', all_players__last_name = "Gray").exclude(team_name = "Colts"),
		"all_players_joshua_Atlantic_Federation": Player.objects.filter(first_name="Joshua", all_teams__league__name='Atlantic Federation of Amateur Baseball Players'),
		"teams_12_players": Team.objects.all().annotate(player_count= Count('all_players')).filter(player_count__gte=12),
		"players_sorted_by_number_of_teams": Player.objects.all().annotate(team_count= Count('all_teams')).order_by('-team_count'),
	
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")