from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"baseball_leagues": League.objects.filter(sport='Baseball'),
		"women_leagues": League.objects.filter(name__contains='Women'),
		"hockey_leagues": League.objects.filter(sport__contains='Hockey'),
		"not_football_leagues": League.objects.exclude(sport='Football'),
		"conference_leagues": League.objects.filter(name__contains='Conference'),
		"atlantic_leagues": League.objects.filter(name__contains='Atlantic'),
		"dallas_teams": Team.objects.filter(location='Dallas'),
		"raptors_teams": Team.objects.filter(team_name='Raptors'),
		"city_teams": Team.objects.filter(location__contains='City'),
		"T_teams": Team.objects.filter(team_name__startswith="T"),
		"alpha_teams": Team.objects.all().order_by('location'),
		"backwards_teams": Team.objects.all().order_by('-team_name'),
		"cooper_player": Player.objects.filter(last_name='Cooper'),
		"joshua_player": Player.objects.filter(first_name='Joshua'),
		"cooper_notjosh_player": Player.objects.filter(last_name='Cooper').exclude(first_name='Joshua'),
		"alexander_wyatt_player": Player.objects.filter(first_name='Alexander')|Player.objects.filter(first_name='Wyatt'),
		
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")